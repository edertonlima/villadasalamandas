<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'villadasalamandas');

/** MySQL database username */
define('DB_USER', 'villadasalamanda');

/** MySQL database password */
define('DB_PASSWORD', 'eK6pngd4FzqCSCW5');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8mb4');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'L0]2rK($o,r;mQ/!+m&L3cHck1C(k;JA/nFQx Gk:[fv5g4opk}ZS5y:Q?fYb@fx');
define('SECURE_AUTH_KEY',  ';fa PsS:K:ge`!&ge&>l}G(UleTlp.mJSd2}efzd^>oWR,0lPz(R.o`kl,KnN~kH');
define('LOGGED_IN_KEY',    ',v/-PDA5JuI}mkb1Ot<.YjRY>V[/L0)yti_rWNN>=n@me$LesH%POzz^i)ufw%%g');
define('NONCE_KEY',        '/7&^hj.sR!1mP8mBSaL.6p{NiNSKai3XxA9&<Lop<aEpU4QZF7pg,^xG7vI.MnNo');
define('AUTH_SALT',        'u;,3)EWbbd|/2b`;imW/%pY}(9CPD(YYUEpYRx2{~<<k.J>M{@NL0Gh8g,EYa1kK');
define('SECURE_AUTH_SALT', 'IWx0bu<&a(mkFkY%coveOs:7XM3+RC>o6g@=q#H{&IO{H@Oz+}7VLg0XUK}+B]vs');
define('LOGGED_IN_SALT',   'P?r96^G;x#N`w&zB|qM,Ov*;4*xL$@-A%27/KtPF[xM|7gWq#2BsAm33jHZp%yg/');
define('NONCE_SALT',       '/*no/vMk[-x%vxHDR-B0zKTAp/+}<aeA%Kb]|}/DT,tWFp<CT]29hLaDy^o5cQIj');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
